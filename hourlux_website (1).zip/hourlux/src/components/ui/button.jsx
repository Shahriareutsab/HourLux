
export function Button({ children, className = '', variant = 'solid', ...props }) {
  const base = 'px-4 py-2 rounded-xl font-semibold transition-all duration-300';
  const variants = {
    solid: 'bg-yellow-400 text-black hover:bg-yellow-300',
    outline: 'border border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black',
    ghost: 'hover:bg-gray-700',
  };
  return (
    <button className={\`\${base} \${variants[variant]} \${className}\`} {...props}>
      {children}
    </button>
  );
}
