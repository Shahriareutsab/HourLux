
import React from "react";
import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { ShoppingCart, Clock, Filter, CreditCard, User } from "lucide-react";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gray-900 text-white font-sans">
      <header className="p-6 flex items-center justify-between border-b border-gray-700">
        <h1 className="text-3xl font-bold text-yellow-400 flex items-center gap-2">
          <Clock className="w-6 h-6" /> HourLux
        </h1>
        <div className="flex items-center gap-4">
          <Button variant="ghost" className="text-white">
            <User className="mr-2 w-5 h-5" /> Account
          </Button>
          <Button variant="ghost" className="text-white">
            <ShoppingCart className="mr-2 w-5 h-5" /> Cart
          </Button>
        </div>
      </header>

      <section className="p-8 text-center">
        <h2 className="text-4xl font-semibold mb-4">Luxury Watches for Timeless Elegance</h2>
        <p className="text-gray-300 mb-8">Explore premium collections from Rolex, Citizen, and more.</p>
        <Button className="bg-yellow-400 text-black hover:bg-yellow-300">Shop Now</Button>
      </section>

      <section className="px-8 pb-4 flex items-center gap-4">
        <Filter className="text-yellow-400" />
        <select className="bg-gray-800 text-white border border-gray-600 rounded px-3 py-2">
          <option>All Brands</option>
          <option>Rolex</option>
          <option>Citizen</option>
        </select>
        <select className="bg-gray-800 text-white border border-gray-600 rounded px-3 py-2">
          <option>Sort by</option>
          <option>Price: Low to High</option>
          <option>Price: High to Low</option>
        </select>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 p-8">
        {[
          { name: "Rolex Submariner", price: "৳850,000", image: "/images/rolex-submariner.jpg" },
          { name: "Citizen Eco-Drive", price: "৳28,000", image: "/images/citizen-eco.jpg" },
          { name: "Rolex Daytona", price: "৳1,200,000", image: "/images/rolex-daytona.jpg" },
        ].map((watch, idx) => (
          <Card key={idx} className="bg-gray-800 border-none text-white">
            <img src={watch.image} alt={watch.name} className="w-full h-48 object-cover rounded-t-2xl" />
            <CardContent className="p-4">
              <h3 className="text-xl font-semibold mb-1">{watch.name}</h3>
              <p className="text-yellow-400 mb-3">{watch.price}</p>
              <Button variant="outline" className="text-yellow-400 border-yellow-400 hover:bg-yellow-400 hover:text-black">
                Add to Cart
              </Button>
            </CardContent>
          </Card>
        ))}
      </section>

      <section className="p-8 bg-gray-800 text-center rounded-2xl mx-4 mt-10">
        <h3 className="text-2xl font-semibold mb-4">Secure Payments with Bkash & Nagad</h3>
        <p className="text-gray-300 mb-4">We support instant mobile transactions for your convenience.</p>
        <div className="flex justify-center gap-4">
          <Button className="bg-pink-500 text-white hover:bg-pink-400">
            <CreditCard className="mr-2 w-4 h-4" /> Pay with Bkash
          </Button>
          <Button className="bg-orange-500 text-white hover:bg-orange-400">
            <CreditCard className="mr-2 w-4 h-4" /> Pay with Nagad
          </Button>
        </div>
      </section>

      <footer className="p-6 text-center text-gray-500 border-t border-gray-700 mt-10">
        © 2025 HourLux. All rights reserved.
      </footer>
    </div>
  );
}
